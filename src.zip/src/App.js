import React, { Component } from 'react';
import './App.css';
import Person from './Person/Person';

class App extends Component {
  state = {
    persons: [
      {name: 'Max', age: 28},
      {name: 'Jordan', age:20},
      {name: 'bill', age: 25}
    ],
    showPersons: false
  }

  switchNameHandler = (newName) => {
    // console.log('was clicked');
    this.setState({persons: [
          {name: newName, age: 28},
          {name: 'Jordan', age:20},
          {name: 'bill', age: 27}
        ]})
  }

  nameChangedHadler = (event) => {
    this.setState({persons: [
          {name: 'Max', age: 28},
          {name: 'Jordan', age:20},
          {name: event.target.value, age: 27}
        ]})
  }

  togglePersonsHandler = () => {

  }

  render() {
    const style ={
      backgroundColor:'white',
      font: "inherit",
      border: '1px solid blue',
      padding: '8px',
      cursor: 'pointer'
    };
    return (
      <div className="App">
        <h1>Hi, im a react App!</h1>
        <p> This is really working!</p>
        <button style={style} onClick={this.togglePersonsHandler}>Switch Name</button>
        {this.state.showPersons ?
          <div>
          <Person
            name={this.state.persons[0].name}
            age={this.state.persons[0].age}
            click={this.switchNameHandler.bind(this,'maxi boi!!!')}
          />
          <Person
            name={this.state.persons[1].name}
            age={this.state.persons[1].age}>Im learning React!</Person>
          <Person
            name={this.state.persons[2].name}
            age={this.state.persons[2].age}
            changed={this.nameChangedHadler} />
          </div>
        }
      </div>
    );
    // return React.createElement('div', {className: 'App'}, React.createElement('h1', null, "Hi i\'m a React App!!"));
  }
}

export default App;
